﻿7+3 programmé par Red-Error Suru

Version standalone : lancer spt.exe pour lancer le jeu
Jouer avec la souris et les touches clavier Haut, Bas
Droite/Espace/Enter pour sélectionner, R pour recommencer, Esc pour quitter la partie
8 niveaux arcade, 5 niveaux puzzle
1 personnage secret si vous finissez le mode arcade!




Pour le concours "10 secondes" du CBNA organisé par Onlilink

http://cbna.forumactif.com/t12764-concours-02-dix-secondes

Programmé avec python 2.7 et pygame, exeifié (péniblement) avec py2exe